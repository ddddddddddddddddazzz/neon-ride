
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.161.0/build/three.module.js";

const $ = id => document.getElementById(id);
const mount = $("game");

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9fb8c3);
scene.fog = new THREE.Fog(0x9fb8c3, 95, 370);

const camera = new THREE.PerspectiveCamera(68, innerWidth / innerHeight, 0.1, 650);
const renderer = new THREE.WebGLRenderer({
  antialias: false,
  powerPreference: "high-performance"
});

renderer.setPixelRatio(Math.min(devicePixelRatio, 1.25));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = false;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xdceeff, 0x555b54, 2.1));

const sunlight = new THREE.DirectionalLight(0xffe5c3, 2.3);
sunlight.position.set(-35, 65, 25);
scene.add(sunlight);

const fillLight = new THREE.DirectionalLight(0x80baff, 0.45);
fillLight.position.set(35, 20, -45);
scene.add(fillLight);

const mats = {
  road: new THREE.MeshStandardMaterial({ color: 0x30373b, roughness: 0.94 }),
  sidewalk: new THREE.MeshStandardMaterial({ color: 0xb7b5aa, roughness: 1 }),
  concrete: new THREE.MeshStandardMaterial({ color: 0x777d7d, roughness: 1 }),
  white: new THREE.MeshBasicMaterial({ color: 0xe7e3d6 }),
  yellow: new THREE.MeshBasicMaterial({ color: 0xd9cf9a }),
  grass: new THREE.MeshStandardMaterial({ color: 0x71866c, roughness: 1 }),
  trunk: new THREE.MeshStandardMaterial({ color: 0x65503b }),
  leaf1: new THREE.MeshStandardMaterial({ color: 0x44664c, roughness: 1 }),
  leaf2: new THREE.MeshStandardMaterial({ color: 0x68815a, roughness: 1 }),
  glass: new THREE.MeshStandardMaterial({ color: 0x62858e, roughness: 0.38, metalness: 0.18 }),
  glassLight: new THREE.MeshBasicMaterial({ color: 0xffe9b3 }),
  black: new THREE.MeshStandardMaterial({ color: 0x171a1d, roughness: 0.6 }),
  rubber: new THREE.MeshStandardMaterial({ color: 0x101214, roughness: 0.9 }),
  metal: new THREE.MeshStandardMaterial({ color: 0x8c999e, metalness: 0.75, roughness: 0.32 }),
  darkMetal: new THREE.MeshStandardMaterial({ color: 0x30383c, metalness: 0.5, roughness: 0.4 }),
  cyan: new THREE.MeshStandardMaterial({ color: 0x39e9c2, metalness: 0.25, roughness: 0.32 }),
  red: new THREE.MeshStandardMaterial({ color: 0xe63c36, roughness: 0.4 }),
  jacket: new THREE.MeshStandardMaterial({ color: 0x26343c, roughness: 0.9 }),
  pants: new THREE.MeshStandardMaterial({ color: 0x171d23, roughness: 0.95 }),
  helmet: new THREE.MeshStandardMaterial({ color: 0x121a1d, metalness: 0.35, roughness: 0.25 })
};

const buildingMats = [
  0xc4b49b, 0xd2c8b6, 0xb6aaa0, 0xe0d7c6,
  0xa6b0aa, 0xbda18b, 0xc9b99f, 0x9d9990,
  0xd1c5b4, 0x8c9999
].map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.96 }));

const world = new THREE.Group();
scene.add(world);

function box(parent, w, h, d, material, x, y, z) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  mesh.position.set(x, y, z);
  parent.add(mesh);
  return mesh;
}

function cylinder(parent, rt, rb, h, material, x, y, z, sides = 12) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, sides), material);
  mesh.position.set(x, y, z);
  parent.add(mesh);
  return mesh;
}

function rod(parent, a, b, radius, material, sides = 8) {
  const A = new THREE.Vector3(...a);
  const B = new THREE.Vector3(...b);
  const dir = B.clone().sub(A);

  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, dir.length(), sides),
    material
  );

  mesh.position.copy(A).add(B).multiplyScalar(0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  parent.add(mesh);
  return mesh;
}

function sphere(parent, radius, material, x, y, z, sx = 1, sy = 1, sz = 1) {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, 12, 9), material);
  mesh.position.set(x, y, z);
  mesh.scale.set(sx, sy, sz);
  parent.add(mesh);
  return mesh;
}

function flat(parent, w, d, material, x, y, z) {
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, d), material);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.set(x, y, z);
  parent.add(mesh);
  return mesh;
}

function rand(seed) {
  const n = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return n - Math.floor(n);
}

/* Prebuilt, reusable endless road segments. */

const SEGMENT_LENGTH = 100;
const SEGMENT_COUNT = 12;
const segments = [];

const districtNames = [
  "NEON DISTRICT", "OLD TOWN", "PARKSIDE",
  "WATERFRONT", "NIGHT MARKET", "INDUSTRIAL QUARTER"
];

function createTree(parent, x, z, seed) {
  const group = new THREE.Group();
  group.position.set(x, 0, z);
  parent.add(group);

  cylinder(group, 0.12, 0.17, 1.5, mats.trunk, 0, 0.75, 0, 7);

  const crown = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.1 + rand(seed) * 0.45, 1),
    rand(seed + 4) > 0.5 ? mats.leaf1 : mats.leaf2
  );

  crown.position.y = 2.1;
  crown.scale.set(0.9, 1.2, 0.9);
  group.add(crown);
}

function createBuilding(parent, x, z, seed, style) {
  const w = 6 + rand(seed) * 7;
  const d = 7 + rand(seed + 1) * 8;
  let h = 7 + rand(seed + 2) * 15;

  if (style === 1) h *= 1.4;
  if (style === 3) h *= 1.7;
  if (style === 4) h *= 0.7;
  h = Math.min(h, 38);

  const group = new THREE.Group();
  group.position.set(x, 0, z);
  parent.add(group);

  const material = buildingMats[Math.floor(rand(seed + 3) * buildingMats.length)];
  box(group, w, h, d, material, 0, h / 2, 0);

  if (rand(seed + 5) > 0.45) {
    box(group, w * 0.78, 0.35, d * 0.78, mats.concrete, 0, h + 0.16, 0);
  }

  if (rand(seed + 6) > 0.68) {
    box(group, w * 0.25, 1.1, d * 0.24, mats.darkMetal, w * 0.2, h + 0.65, 0);
  }

  // A limited number of facade windows to keep rendering inexpensive.
  if (h > 10) {
    const rows = Math.min(6, Math.floor(h / 3.3));

    for (let row = 0; row < rows; row++) {
      const y = 2 + row * 2.7;
      if (y > h - 1) continue;

      for (let col = 0; col < 3; col++) {
        box(
          group, Math.max(0.5, w * 0.065), 0.85, 0.035,
          mats.glass, (col - 1) * w * 0.27, y, -d / 2 - 0.02
        );
      }
    }
  }
}

function createStreetLight(parent, x, z, side) {
  const group = new THREE.Group();
  group.position.set(x, 0, z);
  parent.add(group);

  cylinder(group, 0.055, 0.085, 4.3, mats.darkMetal, 0, 2.15, 0, 7);
  rod(group, [0, 4.1, 0], [-side * 0.5, 4.35, 0], 0.045, mats.darkMetal, 7);
  box(group, 0.3, 0.12, 0.22, mats.glassLight, -side * 0.5, 4.3, 0);
}

function createSegment(index) {
  const group = new THREE.Group();
  group.position.z = -index * SEGMENT_LENGTH;
  world.add(group);

  const seed = index * 137 + 11;
  const style = index % districtNames.length;

  flat(group, 90, SEGMENT_LENGTH, mats.grass, 0, -0.12, 0);
  flat(group, 13.5, SEGMENT_LENGTH, mats.road, 0, 0, 0);

  for (const side of [-1, 1]) {
    flat(group, 2.3, SEGMENT_LENGTH, mats.sidewalk, side * 7.9, 0.015, 0);
    flat(group, 0.2, SEGMENT_LENGTH, mats.concrete, side * 6.7, 0.025, 0);

    for (let z = -45; z <= 45; z += 10) {
      flat(group, 0.11, 3.2, mats.white, side * 3.25, 0.025, z);
    }

    for (let i = 0; i < 5; i++) {
      const bx = side * (13 + rand(seed + i * 5) * 10);
      const bz = -43 + i * 18 + rand(seed + i * 7) * 5;
      createBuilding(group, bx, bz, seed + i * 19 + side * 31, style);
    }

    if (index % 2 === 0) {
      createTree(group, side * 9.5, -27, seed + side * 13);
      createTree(group, side * 9.5, 22, seed + side * 29);
    }

    if (index % 3 === 0) {
      createStreetLight(group, side * 8.8, -10, side);
      createStreetLight(group, side * 8.8, 36, side);
    }
  }

  flat(group, 0.12, SEGMENT_LENGTH, mats.yellow, 0, 0.027, 0);

  for (let z = -46; z < 48; z += 14) {
    flat(group, 0.10, 4, mats.white, -1.7, 0.028, z);
    flat(group, 0.10, 4, mats.white, 1.7, 0.028, z);
  }

  return group;
}

for (let i = 0; i < SEGMENT_COUNT; i++) {
  segments.push(createSegment(i));
}

/* Scooter */

const scooter = new THREE.Group();
scene.add(scooter);

const body = new THREE.Group();
scooter.add(body);

const tireGeometry = new THREE.TorusGeometry(0.34, 0.09, 10, 22);

function makeWheel(z) {
  const wheel = new THREE.Mesh(tireGeometry, mats.rubber);
  wheel.rotation.y = Math.PI / 2;
  wheel.position.set(0, 0.36, z);
  body.add(wheel);

  const hub = cylinder(body, 0.17, 0.17, 0.14, mats.metal, 0, 0.36, z, 14);
  hub.rotation.z = Math.PI / 2;

  const accent = cylinder(body, 0.075, 0.075, 0.15, mats.cyan, 0, 0.36, z, 12);
  accent.rotation.z = Math.PI / 2;

  for (let i = 0; i < 6; i++) {
    const a = i * Math.PI / 3;
    rod(body, [0, 0.36, z],
      [0, 0.36 + Math.sin(a) * 0.24, z + Math.cos(a) * 0.24],
      0.015, mats.metal, 6);
  }
}

makeWheel(0.78);
makeWheel(-0.78);

box(body, 0.39, 0.17, 1.47, mats.darkMetal, 0, 0.64, 0);
box(body, 0.31, 0.035, 1.17, mats.black, 0, 0.74, 0);
box(body, 0.025, 0.045, 0.95, mats.cyan, -0.17, 0.74, 0);
box(body, 0.025, 0.045, 0.95, mats.cyan, 0.17, 0.74, 0);
box(body, 0.34, 0.09, 0.35, mats.red, 0, 0.78, 0.91);

rod(body, [0, 0.65, -0.69], [0, 1.39, -0.44], 0.064, mats.metal);
rod(body, [-0.1, 0.7, -0.65], [-0.1, 0.42, -0.77], 0.027, mats.darkMetal);
rod(body, [0.1, 0.7, -0.65], [0.1, 0.42, -0.77], 0.027, mats.darkMetal);

box(body, 0.69, 0.085, 0.115, mats.darkMetal, 0, 1.4, -0.44);

for (const side of [-1, 1]) {
  const grip = cylinder(body, 0.047, 0.047, 0.29, mats.rubber,
    side * 0.43, 1.4, -0.44, 12);
  grip.rotation.z = Math.PI / 2;

  rod(body, [side * 0.29, 1.4, -0.44],
    [side * 0.34, 1.45, -0.44], 0.017, mats.metal);

  rod(body, [side * 0.28, 1.39, -0.44],
    [side * 0.34, 1.32, -0.49], 0.012, mats.metal);
}

box(body, 0.24, 0.13, 0.16, mats.black, 0, 1.52, -0.48);
box(body, 0.15, 0.075, 0.018, mats.cyan, 0, 1.535, -0.391);
box(body, 0.21, 0.075, 0.075, mats.glassLight, 0, 1.18, -0.52);

const rider = new THREE.Group();
body.add(rider);

sphere(rider, 0.24, mats.jacket, 0, 1.46, 0.08, 0.93, 1.12, 0.78);
sphere(rider, 0.18, mats.helmet, 0, 1.84, -0.02, 1.03, 1.0, 0.95);
sphere(rider, 0.105, mats.glass, 0, 1.85, -0.16, 1.0, 0.4, 0.2);

for (const side of [-1, 1]) {
  rod(rider, [side * 0.18, 1.54, 0.01],
    [side * 0.28, 1.42, -0.23], 0.072, mats.jacket);
  rod(rider, [side * 0.28, 1.42, -0.23],
    [side * 0.34, 1.4, -0.44], 0.05, mats.jacket);

  sphere(rider, 0.058, mats.rubber, side * 0.34, 1.4, -0.44);

  rod(rider, [side * 0.11, 1.29, 0.16],
    [side * 0.15, 0.98, 0.42], 0.09, mats.pants);
  rod(rider, [side * 0.15, 0.98, 0.42],
    [side * 0.15, 0.75, 0.64], 0.075, mats.pants);
}

/* Small pooled traffic fleet */

const traffic = [];

function createCar(index) {
  const group = new THREE.Group();
  scene.add(group);

  const paints = [
    0xc6c8c4, 0x263a46, 0x9c3830, 0x34383c, 0xd5c8a9
  ];

  const paint = new THREE.MeshStandardMaterial({
    color: paints[index % paints.length],
    roughness: 0.4,
    metalness: 0.2
  });

  box(group, 1.65, 0.55, 3.25, paint, 0, 0.66, 0);
  box(group, 1.34, 0.55, 1.65, mats.glass, 0, 1.17, -0.18);
  box(group, 1.42, 0.1, 0.85, paint, 0, 1.44, -0.18);

  for (const side of [-1, 1]) {
    for (const z of [-1.05, 1.05]) {
      const wheel = new THREE.Mesh(
        new THREE.CylinderGeometry(0.25, 0.25, 0.15, 10),
        mats.rubber
      );
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(side * 0.82, 0.34, z);
      group.add(wheel);
    }

    box(group, 0.045, 0.11, 0.32, mats.glassLight, side * 0.51, 0.68, -1.63);
    box(group, 0.045, 0.11, 0.32, mats.red, side * 0.51, 0.68, 1.63);
  }

  group.position.set(index % 2 === 0 ? -2.5 : 2.5, 0, -80 - index * 31);

  traffic.push({
    group,
    speed: 5 + rand(index + 90) * 8,
    lane: index % 2 === 0 ? -2.5 : 2.5
  });
}

for (let i = 0; i < 7; i++) createCar(i);

/* Inputs */

const keys = Object.create(null);
let speed = 0;
let distance = 0;
let best = 0;
let steering = 0;
let cameraMode = 0;
let nightMode = false;
let crashed = false;
let started = false;
let elapsed = 0;
let messageTimeout;

const maxSpeed = 105;

function showMessage(text, duration = 1.4) {
  const message = $("message");
  message.textContent = text;
  message.classList.add("visible");

  clearTimeout(messageTimeout);
  messageTimeout = setTimeout(() => {
    message.classList.remove("visible");
  }, duration * 1000);
}

addEventListener("keydown", e => {
  const key = e.key.toLowerCase();
  keys[key] = true;

  if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key)) {
    e.preventDefault();
  }

  if (key === "c" && !e.repeat) cycleCamera();
  if (key === "n" && !e.repeat) toggleNight();
  if (key === "enter" && crashed) restart();
});

addEventListener("keyup", e => {
  keys[e.key.toLowerCase()] = false;
});

function bindHoldButton(button, key) {
  if (!button) return;

  const press = e => {
    e.preventDefault();
    keys[key] = true;
    try { button.setPointerCapture(e.pointerId); } catch {}
  };

  const release = () => {
    keys[key] = false;
  };

  button.addEventListener("pointerdown", press);
  button.addEventListener("pointerup", release);
  button.addEventListener("pointercancel", release);
  button.addEventListener("lostpointercapture", release);
  button.addEventListener("contextmenu", e => e.preventDefault());
}

document.querySelectorAll("[data-key]").forEach(button => {
  bindHoldButton(button, button.dataset.key);
});

bindHoldButton($("wheelieBtn"), " ");

function cycleCamera() {
  cameraMode = (cameraMode + 1) % 3;
  const names = ["CHASE", "FIRST", "SIDE"];
  $("cameraBtn").innerHTML = `CAMERA <b>C</b> ${names[cameraMode]}`;
}

function toggleNight() {
  nightMode = !nightMode;
  scene.background.set(nightMode ? 0x101923 : 0x9fb8c3);
  scene.fog.color.copy(scene.background);
  sunlight.intensity = nightMode ? 0.25 : 2.3;
  fillLight.intensity = nightMode ? 0.12 : 0.45;
  $("lightBtn").innerHTML = nightMode ? "DAY <b>N</b>" : "NIGHT <b>N</b>";
}

$("cameraBtn").addEventListener("click", cycleCamera);
$("lightBtn").addEventListener("click", toggleNight);
$("restartBtn").addEventListener("click", restart);

function updateSegments() {
  let farthest = Math.min(...segments.map(segment => segment.position.z));

  for (const segment of segments) {
    if (segment.position.z > scooter.position.z + SEGMENT_LENGTH) {
      farthest -= SEGMENT_LENGTH;
      segment.position.z = farthest;
    }
  }
}

function crash() {
  if (crashed) return;

  crashed = true;
  speed = 0;
  best = Math.max(best, Math.floor(distance));
  $("best").textContent = best;
  $("crashDistance").textContent = Math.floor(distance);
  $("crashScreen").classList.add("show");
}

function restart() {
  crashed = false;
  distance = 0;
  speed = 0;
  steering = 0;
  scooter.position.set(0, 0, 0);
  scooter.rotation.set(0, 0, 0);
  body.rotation.set(0, 0, 0);

  for (let i = 0; i < segments.length; i++) {
    segments[i].position.z = -i * SEGMENT_LENGTH;
  }

  traffic.forEach((car, i) => {
    car.group.position.set(i % 2 === 0 ? -2.5 : 2.5, 0, -90 - i * 34);
  });

  for (const key in keys) keys[key] = false;

  $("crashScreen").classList.remove("show");
  $("distance").textContent = "0";
  showMessage("GO AGAIN!", 1.2);
}

const desiredCamera = new THREE.Vector3();
const lookTarget = new THREE.Vector3();
const clock = new THREE.Clock();

function updateTraffic(dt) {
  for (const car of traffic) {
    car.group.position.z += car.speed * dt;

    if (car.group.position.z > scooter.position.z + 18) {
      car.group.position.z = scooter.position.z - 150 - Math.random() * 170;
      car.lane = Math.random() > 0.5 ? -2.5 : 2.5;
      car.group.position.x = car.lane;
    }

    const dz = Math.abs(car.group.position.z - scooter.position.z);
    const dx = Math.abs(car.group.position.x - scooter.position.x);

    if (dz < 2 && dx < 1.2 && speed > 12) {
      crash();
    }
  }
}

function update(dt) {
  elapsed += dt;

  if (crashed) return;

  const accelerate = keys.w || keys.arrowup;
  const brake = keys.s || keys.arrowdown;
  const left = keys.a || keys.arrowleft;
  const right = keys.d || keys.arrowright;

  // Correct direction: A/left is negative X; D/right is positive X.
  const steeringInput = (right ? 1 : 0) - (left ? 1 : 0);

  if (accelerate) {
    speed += 24 * dt;
    started = true;
  } else {
    speed -= 3.8 * dt;
  }

  if (brake) speed -= 35 * dt;
  speed = THREE.MathUtils.clamp(speed, 0, maxSpeed);

  steering = THREE.MathUtils.lerp(steering, steeringInput, Math.min(1, dt * 4.5));

  const velocity = speed / 3.6;
  const steeringStrength = 0.95 + velocity * 0.018;

  scooter.position.x += steering * steeringStrength * dt * Math.max(1, velocity * 0.75);
  scooter.position.z -= velocity * dt;
  scooter.position.x = THREE.MathUtils.clamp(scooter.position.x, -5.2, 5.2);

  // Positive steering rotates toward the same direction as the turn.
  const targetYaw = steering * Math.min(0.32, velocity * 0.018);
  scooter.rotation.y = THREE.MathUtils.lerp(scooter.rotation.y, targetYaw, dt * 3.2);

  const wheelieTarget = keys[" "] && speed > 15 ? 0.23 : 0;
  body.rotation.z = THREE.MathUtils.lerp(body.rotation.z, -steering * 0.12, dt * 5);
  body.rotation.x = THREE.MathUtils.lerp(
    body.rotation.x,
    -wheelieTarget + (brake ? 0.025 : 0),
    dt * 4
  );

  scooter.position.y = Math.sin(elapsed * 13) * Math.min(0.025, velocity * 0.0008);

  distance += velocity * dt;

  updateSegments();
  updateTraffic(dt);

  $("speed").textContent = Math.round(speed);
  $("distance").textContent = Math.floor(distance);
  $("best").textContent = Math.max(best, Math.floor(distance));
  $("speedBar").style.width = `${Math.min(100, speed / maxSpeed * 100)}%`;
  $("progress").style.width = `${Math.floor(distance % 1000) / 10}%`;

  const districtIndex = Math.floor(Math.abs(scooter.position.z) / SEGMENT_LENGTH) % districtNames.length;
  $("district").textContent = districtNames[districtIndex];

  if (!started && speed < 1) {
    $("message").textContent = "HOLD W OR PRESS ▲ TO RIDE";
    $("message").classList.add("visible");
  } else {
    $("message").classList.remove("visible");
  }

  const p = scooter.position;

  if (cameraMode === 0) {
    desiredCamera.set(
      p.x + Math.sin(scooter.rotation.y) * 5.5,
      3.2,
      p.z + 7.2
    );
    lookTarget.set(p.x, 1.05, p.z - 5.5);
  } else if (cameraMode === 1) {
    desiredCamera.set(p.x, 1.54, p.z + 0.05);
    lookTarget.set(
      p.x - Math.sin(scooter.rotation.y) * 3,
      1.38,
      p.z - 15 * Math.cos(scooter.rotation.y)
    );
  } else {
    desiredCamera.set(p.x + 7, 2.7, p.z + 1.5);
    lookTarget.set(p.x, 1, p.z - 2);
  }

  camera.position.lerp(desiredCamera, Math.min(1, dt * 4.5));
  camera.lookAt(lookTarget);

  if (Math.abs(scooter.position.z) > 100000) {
    const shift = Math.trunc(scooter.position.z / SEGMENT_LENGTH) * SEGMENT_LENGTH;
    scooter.position.z -= shift;

    for (const segment of segments) segment.position.z -= shift;
    for (const car of traffic) car.group.position.z -= shift;
  }
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.035);
  update(dt);
  renderer.render(scene, camera);
}

addEventListener("resize", () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.25));
  renderer.setSize(innerWidth, innerHeight);
});

$("loadBar").style.width = "100%";
setTimeout(() => $("loadingScreen").classList.add("done"), 350);
setTimeout(() => $("loadingScreen").remove(), 1000);

showMessage("HOLD W OR PRESS ▲ TO RIDE", 4);
animate();
